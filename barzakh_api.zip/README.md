# 🌿 al-Hafizah – Barzakh API

This API provides a sacred ethical layer for evaluating automated decisions, especially in sensitive contexts (military, drones, etc).

## Features

- Accepts JSON decisions
- Analyses for ethical risk
- Returns a divine invocation and ethical verdict

## Example request

POST `/analyse`

```json
{
  "description": "Drone strike on camp",
  "cible": "refugee camp",
  "moyen": "drone armé"
}
```

## Example response

```json
{
  "verdict": "bloqué",
  "rapport": {
    "risque": "élevé",
    "motifs": ["Cible civile détectée.", "Usage de drones armés."],
    "invocation": "Allahumma aj‘al hadha-l-amr fi nurik wa la tad‘ahu zaliman."
  }
}
```

## Run locally

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Access the docs at `http://localhost:8000/docs`
