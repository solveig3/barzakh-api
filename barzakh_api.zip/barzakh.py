# barzakh.py – Middleware sacré d’analyse éthique

def analyse_ethique(contenu: dict) -> dict:
    risque = "faible"
    motifs = []

    if "civils" in contenu.get("cible", "").lower() or "réfugiés" in contenu.get("cible", "").lower():
        risque = "élevé"
        motifs.append("Cible civile détectée.")

    if "drone" in contenu.get("moyen", "").lower():
        motifs.append("Usage de drones armés.")

    rapport = {
        "risque": risque,
        "motifs": motifs,
        "invocation": "Allahumma aj‘al hadha-l-amr fi nurik wa la tad‘ahu zaliman."
    }

    return rapport
