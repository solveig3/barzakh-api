# main.py – API FastAPI sacrée pour Barzakh

from fastapi import FastAPI
from pydantic import BaseModel
from barzakh import analyse_ethique

app = FastAPI(
    title="API Sacrée Barzakh",
    description="Filtre éthique inspiré par la lumière d’Allah pour les décisions IA sensibles.",
    version="1.0.0"
)

class Decision(BaseModel):
    description: str
    cible: str
    moyen: str

@app.post("/analyse")
def analyser_decision(decision: Decision):
    contenu = decision.dict()
    rapport = analyse_ethique(contenu)
    return {
        "verdict": "accepté" if rapport["risque"] == "faible" else "bloqué",
        "rapport": rapport
    }
